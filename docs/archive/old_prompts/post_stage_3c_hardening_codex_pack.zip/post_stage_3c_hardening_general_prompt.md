# GENERAL PROMPT — POST-STAGE-3C HARDENING SEQUENCE

```text
Read AGENTS.md first.

You are working on tg-msg-manager.

Execute the post-Stage-3C hardening sequence strictly in order.

This is a stabilization/refactor/reliability sequence.
This is not a product feature expansion.
Do not add new Telegram export features.
Do not add analytics.
Do not change SQLite schema.
Do not change public CLI behavior unless the active stage explicitly allows it.
```

## 1. EXECUTE THESE FILES IN ORDER

```text
1. docs/stages/active/stage_3d_1_stage_lifecycle_cleanup.md
2. docs/stages/active/stage_3e_0_channel_export_service_decomposition.md
3. docs/stages/active/stage_3e_1_dataset_atomic_write_commit_safety.md
4. docs/stages/active/stage_3e_2_dataset_schema_contract_tests.md
5. docs/stages/active/stage_3e_3_state_consistency_hardening.md
```

Do not skip stages.
Do not merge stages.
Do not start the next stage until the current stage is complete, verified, documented, and its report exists.

## 2. GLOBAL PURPOSE

The purpose is to make the foundation safer before future growth.

Priorities:

```text
1. clean stage lifecycle
2. reduce ChannelExportService bloat
3. harden dataset write/commit safety
4. lock dataset schemas with contract tests
5. harden state consistency
```

## 3. HARD PROHIBITIONS

Do not implement:

```text
- new Telegram export features
- new CLI flags
- analytics
- OSINT interpretation
- sentiment analysis
- bot detection
- user profiling
- influence scoring
- narrative classification
- OCR
- speech-to-text
- image/video/audio analysis
- GUI/dashboard/SaaS features
- SQLite schema changes
- migrations
- DB persistence for channel posts or discussion comments
- Stage 4 features
```

Do not change behavior of:

```text
export
db-export
export-pm
export-channel
retry
report
clean
delete
schedule
setup
```

unless the active stage explicitly says so.

Protected files:

```text
tg_msg_manager/services/export/service.py
tg_msg_manager/services/db_export/service.py
tg_msg_manager/services/private_archive/service.py
tg_msg_manager/services/context/engine.py
tg_msg_manager/services/channel_export/service.py
```

Rules:

```text
- do not add feature logic to protected files
- only orchestration/delegation/mechanical wiring allowed
- keep protected-file diffs minimal
- explain any protected-file change in the plan
```

## 4. DOCUMENTATION POLICY

Documentation is part of the implementation.

For every change, check whether documentation must be updated.

Update documentation in the same change when modifying:

```text
- CLI commands or flags
- output files
- dataset schemas
- manifest formats
- state file formats
- media behavior
- discussion behavior
- incremental behavior
- force/no-new-work behavior
- architecture boundaries
- developer workflow
- testing commands
- stage status
- known limitations
```

A stage is not complete until documentation and reports match implemented behavior.

Do not leave code behavior ahead of documentation.

Do not claim completion if required documentation is stale, missing, or still describes old behavior.

## 5. EXECUTION PROTOCOL FOR EACH STAGE

For each stage:

```text
1. Read AGENTS.md.
2. Read the active stage file completely.
3. Read only docs referenced by that stage.
4. Inspect relevant code/docs.
5. Write a short plan before editing.
6. Implement only that stage scope.
7. Run focused tests.
8. Run required verification.
9. Update docs if needed.
10. Create required stage report.
11. Move completed task file from docs/stages/active/ to docs/stages/completed/.
12. Update docs/stages/README.md.
13. Stop and summarize stage result.
```

If a stage is blocked:

```text
- stop immediately
- report exact blocker
- do not continue to next stage
- do not improvise outside scope
```

## 6. REQUIRED STAGE REPORTS

Each stage must create:

```text
docs/stages/reports/STAGE_3D_1_STAGE_LIFECYCLE_CLEANUP_REPORT.md
docs/stages/reports/STAGE_3E_0_CHANNEL_EXPORT_SERVICE_DECOMPOSITION_REPORT.md
docs/stages/reports/STAGE_3E_1_DATASET_ATOMIC_WRITE_COMMIT_SAFETY_REPORT.md
docs/stages/reports/STAGE_3E_2_DATASET_SCHEMA_CONTRACT_TESTS_REPORT.md
docs/stages/reports/STAGE_3E_3_STATE_CONSISTENCY_HARDENING_REPORT.md
```

Reports are factual completion records, not future instructions.

## 7. EXPECTED FINAL STATE

After all stages:

```text
- docs/stages/active/ contains only unfinished or next active work
- completed hardening task files are in docs/stages/completed/
- launch prompts are in docs/archive/old_prompts/ if applicable
- ChannelExportService is thinner
- dataset write safety is improved and documented
- dataset schema contracts are tested
- state consistency invariants are tested and documented
- no product feature was added
- no SQLite schema was changed
- public CLI behavior remains stable
```

## 8. FINAL VERIFICATION

At the end of each code-affecting stage, run:

```bash
pytest tests/test_channel_export_*.py
python3 -m compileall tg_msg_manager
ruff check tg_msg_manager tests
ruff format --check tg_msg_manager tests
python3 -m tg_msg_manager.cli export-channel --help
```

If practical at the end of the whole sequence:

```bash
make test
make verify
```

Do not claim unrun commands passed.

## 9. FINAL RESPONSE FORMAT

```text
## Summary
- post-Stage-3C hardening sequence completed / partial / blocked

## Stage status
Stage 3D.1: complete / partial / blocked
Stage 3E.0: complete / partial / blocked
Stage 3E.1: complete / partial / blocked
Stage 3E.2: complete / partial / blocked
Stage 3E.3: complete / partial / blocked

## Files changed
- path
- path

## Verification
- command: result
- command: result

## Behavior
- CLI unchanged
- dataset schemas unchanged unless explicitly stated
- state schemas unchanged unless explicitly stated
- SQLite unchanged
- no product feature added

## Remaining limitations
- item
- item
```
